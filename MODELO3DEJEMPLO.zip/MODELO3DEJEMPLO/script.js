// ==========================================
// 🎭 BIG VEGAS - SCRIPT PRINCIPAL
// ==========================================

console.log("🎭 INICIANDO BIG VEGAS CON TUS ARCHIVOS...");

// ===== VARIABLES GLOBALES =====
let scene, camera, renderer, character, mixer, clock;
let moveForward = false, moveBackward = false, moveLeft = false, moveRight = false;
let canJump = false, isRunning = false;
let velocity = new THREE.Vector3();
let direction = new THREE.Vector3();
let actions = {};
let currentAction = null;

// Control del juego
let loadingManager;
let gameState = 'loading';
let filesLoaded = 0;
let totalFiles = 2; // Big Vegas.fbx + Jumping Down.fbx

// ===== CONFIGURACIÓN DE ARCHIVOS DE TU PROYECTO =====
const gameAssets = {
    character: 'assets/models/Big Vegas.fbx',
    jumpAnimation: 'assets/models/Jumping Down.fbx'
};

// ===== INICIALIZACIÓN =====
document.addEventListener('DOMContentLoaded', function() {
    console.log("📁 Proyecto detectado:");
    console.log("   - Big Vegas.fbx (modelo base)");
    console.log("   - Jumping Down.fbx (animación)");
    
    init();
});

function init() {
    console.log("⚙️ Configurando sistema 3D...");
    
    // Inicializar reloj
    clock = new THREE.Clock();
    
    // Configurar loading manager
    setupLoadingManager();
    
    // Crear escena 3D
    createScene();
    
    // Configurar mundo
    setupWorld();
    
    // Cargar archivos de tu proyecto
    loadProjectAssets();
    
    // Configurar controles
    setupControls();
    
    // Event listeners
    window.addEventListener('resize', onWindowResize);
}

function setupLoadingManager() {
    loadingManager = new THREE.LoadingManager();
    
    loadingManager.onProgress = function(url, loaded, total) {
        const percent = (loaded / total) * 100;
        updateLoadingBar(percent);
        console.log(`📦 Cargando: ${Math.round(percent)}%`);
    };
    
    loadingManager.onLoad = function() {
        console.log("✅ Todos los archivos cargados");
        setTimeout(startGame, 800);
    };
    
    loadingManager.onError = function(url) {
        console.error(`❌ Error cargando: ${url}`);
        updateLoadingText(`Error: ${url.split('/').pop()}`);
    };
}

function createScene() {
    // Crear escena
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x87CEEB);
    scene.fog = new THREE.Fog(0x87CEEB, 50, 200);
    
    // Configurar cámara
    camera = new THREE.PerspectiveCamera(
        75, 
        window.innerWidth / window.innerHeight, 
        0.1, 
        2000
    );
    camera.position.set(0, 8, 15);
    
    // Crear renderer
    renderer = new THREE.WebGLRenderer({ 
        antialias: true,
        alpha: false
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputEncoding = THREE.sRGBEncoding;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    
    // Añadir canvas al DOM
    document.getElementById('game-container').appendChild(renderer.domElement);
    
    console.log("✅ Escena 3D creada");
}

function setupWorld() {
    console.log("🌍 Creando mundo para Big Vegas...");
    
    // === ILUMINACIÓN ===
    
    // Luz ambiental
    const ambientLight = new THREE.AmbientLight(0x404040, 0.6);
    scene.add(ambientLight);
    
    // Luz principal (sol)
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1.2);
    directionalLight.position.set(100, 100, 50);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    directionalLight.shadow.camera.near = 0.1;
    directionalLight.shadow.camera.far = 500;
    directionalLight.shadow.camera.left = -100;
    directionalLight.shadow.camera.right = 100;
    directionalLight.shadow.camera.top = 100;
    directionalLight.shadow.camera.bottom = -100;
    scene.add(directionalLight);
    
    // Luz de relleno
    const fillLight = new THREE.DirectionalLight(0xffa500, 0.4);
    fillLight.position.set(-50, 30, -30);
    scene.add(fillLight);
    
    // === SUELO ===
    const groundGeometry = new THREE.PlaneGeometry(200, 200);
    const groundMaterial = new THREE.MeshLambertMaterial({ 
        color: 0x8FBC8F,
        transparent: true,
        opacity: 0.9
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);
    
    // === DECORACIÓN ===
    createWorldDecorations();
    
    console.log("✅ Mundo creado");
}

function createWorldDecorations() {
    // Colores vibrantes
    const colors = [
        0xff6b6b, 0x4ecdc4, 0x45b7d1, 0x96ceb4, 
        0xfeca57, 0xff9ff3, 0x54a0ff, 0x5f27cd
    ];
    
    // Cubos decorativos
    for (let i = 0; i < 15; i++) {
        const size = 1 + Math.random() * 2;
        const boxGeometry = new THREE.BoxGeometry(size, size, size);
        const boxMaterial = new THREE.MeshLambertMaterial({ 
            color: colors[i % colors.length] 
        });
        const box = new THREE.Mesh(boxGeometry, boxMaterial);
        
        box.position.set(
            (Math.random() - 0.5) * 120,
            size / 2,
            (Math.random() - 0.5) * 120
        );
        
        box.rotation.set(
            Math.random() * Math.PI,
            Math.random() * Math.PI,
            Math.random() * Math.PI
        );
        
        box.castShadow = true;
        box.receiveShadow = true;
        scene.add(box);
    }
    
    // Esferas flotantes
    for (let i = 0; i < 10; i++) {
        const sphereGeometry = new THREE.SphereGeometry(0.5 + Math.random() * 0.5);
        const sphereMaterial = new THREE.MeshLambertMaterial({ 
            color: colors[i % colors.length],
            emissive: new THREE.Color(colors[i % colors.length]).multiplyScalar(0.2)
        });
        const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
        
        sphere.position.set(
            (Math.random() - 0.5) * 100,
            3 + Math.random() * 6,
            (Math.random() - 0.5) * 100
        );
        
        // Datos para animación
        sphere.userData = {
            originalY: sphere.position.y,
            bobSpeed: 0.5 + Math.random() * 1.5,
            rotationSpeed: 0.01 + Math.random() * 0.02
        };
        
        scene.add(sphere);
    }
}

function loadProjectAssets() {
    console.log("📁 Cargando archivos de tu proyecto...");
    updateLoadingText("Cargando Big Vegas.fbx...");
    
    // Cargar modelo base primero
    loadCharacterModel();
}

function loadCharacterModel() {
    const fbxLoader = new THREE.FBXLoader(loadingManager);
    
    updateFileStatus('file-base', 'loading');
    
    fbxLoader.load(
        gameAssets.character,
        function(fbx) {
            console.log("✅ Big Vegas.fbx cargado exitosamente");
            setupCharacter(fbx);
            updateFileStatus('file-base', 'success');
            filesLoaded++;
            
            // Cargar animación de salto
            loadJumpAnimation();
        },
        function(progress) {
            const percent = (progress.loaded / progress.total) * 100;
            updateLoadingText(`Big Vegas: ${Math.round(percent)}%`);
        },
        function(error) {
            console.error("❌ Error cargando Big Vegas.fbx:", error);
            updateFileStatus('file-base', 'error');
            createFallbackCharacter();
        }
    );
}

function setupCharacter(fbx) {
    character = fbx;
    
    // Escala típica para modelos de Mixamo
    character.scale.setScalar(0.01);
    character.position.set(0, 0, 0);
    
    // Configurar sombras
    character.traverse(function(child) {
        if (child.isMesh) {
            child.castShadow = true;
            child.receiveShadow = true;
        }
    });
    
    // Añadir a escena
    scene.add(character);
    
    // Crear mixer para animaciones
    mixer = new THREE.AnimationMixer(character);
    
    // Actualizar estado
    document.getElementById('model-status').innerHTML = '<span class="success">✅ Big Vegas</span>';
    
    canJump = true;
    console.log("🎭 Big Vegas configurado");
}

function loadJumpAnimation() {
    console.log("🦘 Cargando animación Jumping Down...");
    updateLoadingText("Cargando Jumping Down.fbx...");
    
    const fbxLoader = new THREE.FBXLoader(loadingManager);
    
    updateFileStatus('file-jump', 'loading');
    
    fbxLoader.load(
        gameAssets.jumpAnimation,
        function(fbx) {
            console.log("✅ Jumping Down.fbx cargado");
            setupJumpAnimation(fbx);
            updateFileStatus('file-jump', 'success');
            filesLoaded++;
        },
        function(progress) {
            const percent = (progress.loaded / progress.total) * 100;
            updateLoadingText(`Jumping Down: ${Math.round(percent)}%`);
        },
        function(error) {
            console.error("❌ Error cargando Jumping Down.fbx:", error);
            updateFileStatus('file-jump', 'error');
            filesLoaded++;
        }
    );
}

function setupJumpAnimation(fbx) {
    if (fbx.animations && fbx.animations.length > 0 && mixer) {
        const clip = fbx.animations[0];
        const action = mixer.clipAction(clip);
        actions['jump'] = action;
        
        console.log("🎬 Animación 'jump' registrada");
        updateCurrentAnimation("Jumping Down disponible");
    } else {
        console.log("⚠️ No se encontró animación en Jumping Down.fbx");
    }
}

function createFallbackCharacter() {
    console.log("🔄 Creando personaje de respaldo...");
    
    // Crear Big Vegas placeholder
    const characterGroup = new THREE.Group();
    
    // Cuerpo principal
    const bodyGeometry = new THREE.BoxGeometry(1.2, 2.5, 0.6);
    const bodyMaterial = new THREE.MeshLambertMaterial({ color: 0x1a1a2e });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.position.y = 1.25;
    body.castShadow = true;
    characterGroup.add(body);

    // Cabeza
    const headGeometry = new THREE.SphereGeometry(0.35);
    const headMaterial = new THREE.MeshLambertMaterial({ color: 0xffddaa });
    const head = new THREE.Mesh(headGeometry, headMaterial);
    head.position.y = 2.8;
    head.castShadow = true;
    characterGroup.add(head);

    // Sombrero elegante
    const hatGeometry = new THREE.CylinderGeometry(0.4, 0.4, 0.2);
    const hatMaterial = new THREE.MeshLambertMaterial({ color: 0x800080 });
    const hat = new THREE.Mesh(hatGeometry, hatMaterial);
    hat.position.y = 3.2;
    hat.castShadow = true;
    characterGroup.add(hat);

    // Brazos
    const armGeometry = new THREE.BoxGeometry(0.3, 1.8, 0.3);
    const armMaterial = new THREE.MeshLambertMaterial({ color: 0x333333 });
    
    [-0.9, 0.9].forEach((x) => {
        const arm = new THREE.Mesh(armGeometry, armMaterial);
        arm.position.set(x, 1.2, 0);
        arm.castShadow = true;
        characterGroup.add(arm);
    });

    // Piernas
    const legGeometry = new THREE.BoxGeometry(0.35, 1.8, 0.35);
    const legMaterial = new THREE.MeshLambertMaterial({ color: 0x111111 });
    
    [-0.3, 0.3].forEach((x) => {
        const leg = new THREE.Mesh(legGeometry, legMaterial);
        leg.position.set(x, -0.15, 0);
        leg.castShadow = true;
        characterGroup.add(leg);
    });

    // Posicionar
    characterGroup.position.set(0, 0.9, 0);
    scene.add(characterGroup);
    
    character = characterGroup;
    canJump = true;
    
    document.getElementById('model-status').innerHTML = '<span class="warning">⚠️ Placeholder</span>';
    console.log("✅ Big Vegas placeholder listo");
}

function startGame() {
    gameState = 'playing';
    
    // Ocultar loading
    document.getElementById('loading').classList.add('hidden');
    
    // Mostrar interfaz
    document.getElementById('controls').classList.remove('hidden');
    document.getElementById('status').classList.remove('hidden');
    document.getElementById('info').classList.remove('hidden');
    
    // Inicializar estado
    updatePlayerState('🧍 Idle');
    
    // Comenzar loop de juego
    animate();
    
    console.log("🎮 ¡BIG VEGAS LISTO PARA JUGAR!");
    console.log("🎯 Archivos cargados:", filesLoaded, "/", totalFiles);
    console.log("🎬 Animaciones disponibles:", Object.keys(actions));
}

// ===== SISTEMA DE CONTROLES =====

function setupControls() {
    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('keyup', onKeyUp);
}

function onKeyDown(event) {
    if (gameState !== 'playing') return;
    
    switch(event.code) {
        case 'KeyW':
            moveForward = true;
            updatePlayerState('🚶 Caminando');
            break;
        case 'KeyS':
            moveBackward = true;
            updatePlayerState('🚶 Caminando');
            break;
        case 'KeyA':
            moveLeft = true;
            updatePlayerState('🚶 Caminando');
            break;
        case 'KeyD':
            moveRight = true;
            updatePlayerState('🚶 Caminando');
            break;
        case 'Space':
            event.preventDefault();
            if (canJump) performJump();
            break;
        case 'ShiftLeft':
            isRunning = true;
            if (moveForward || moveBackward || moveLeft || moveRight) {
                updatePlayerState('🏃 Corriendo');
            }
            break;
        case 'KeyR':
            resetCharacterPosition();
            break;
        case 'Digit1':
            stopAllAnimations();
            updatePlayerState('🧍 Pose Normal');
            break;
        case 'Digit2':
            if (actions.jump) {
                playAnimation('jump');
                updatePlayerState('🦘 Jumping Down');
            }
            break;
    }
}

function onKeyUp(event) {
    switch(event.code) {
        case 'KeyW':
            moveForward = false;
            checkIdleState();
            break;
        case 'KeyS':
            moveBackward = false;
            checkIdleState();
            break;
        case 'KeyA':
            moveLeft = false;
            checkIdleState();
            break;
        case 'KeyD':
            moveRight = false;
            checkIdleState();
            break;
        case 'ShiftLeft':
            isRunning = false;
            if (moveForward || moveBackward || moveLeft || moveRight) {
                updatePlayerState('🚶 Caminando');
            }
            break;
    }
}

function checkIdleState() {
    const isMoving = moveForward || moveBackward || moveLeft || moveRight;
    if (!isMoving && canJump) {
        updatePlayerState('🧍 Idle');
    }
}

function performJump() {
    if (!character) return;
    
    velocity.y += 15;
    canJump = false;
    
    // Reproducir animación de salto si está disponible
    if (actions.jump) {
        playAnimation('jump');
    }
    
    updatePlayerState('🦘 Saltando');
    console.log("🚀 Big Vegas salta!");
}

function resetCharacterPosition() {
    if (!character) return;
    
    character.position.set(0, character.position.y > 0 ? character.position.y : 0, 0);
    velocity.set(0, velocity.y, 0);
    
    stopAllAnimations();
    updatePlayerState('🔄 Reiniciado');
    
    console.log("🔄 Posición de Big Vegas reiniciada");
}

function playAnimation(animationName) {
    if (!actions[animationName] || !mixer) {
        console.log(`⚠️ Animación "${animationName}" no disponible`);
        return;
    }
    
    // Detener animación actual
    if (currentAction) {
        currentAction.fadeOut(0.3);
    }
    
    // Reproducir nueva animación
    const action = actions[animationName];
    action.reset().fadeIn(0.3).play();
    currentAction = action;
    
    updateCurrentAnimation(animationName);
    console.log(`🎬 Reproduciendo: ${animationName}`);
}

function stopAllAnimations() {
    if (currentAction) {
        currentAction.fadeOut(0.3);
        currentAction = null;
    }
    updateCurrentAnimation('Ninguna');
}

// ===== SISTEMA DE MOVIMIENTO =====

function updateMovement(delta) {
    if (!character) return;
    
    // Física básica
    velocity.x -= velocity.x * 10.0 * delta;
    velocity.z -= velocity.z * 10.0 * delta;
    velocity.y -= 9.8 * 15.0 * delta; // Gravedad
    
    // Calcular dirección de movimiento
    direction.z = Number(moveForward) - Number(moveBackward);
    direction.x = Number(moveRight) - Number(moveLeft);
    direction.normalize();
    
    // Velocidad base
    const baseSpeed = 6;
    const speed = isRunning ? baseSpeed * 1.8 : baseSpeed;
    
    // Aplicar movimiento
    if (moveForward || moveBackward) velocity.z -= direction.z * speed * delta;
    if (moveLeft || moveRight) velocity.x -= direction.x * speed * delta;
    
    // Rotar personaje hacia la dirección de movimiento
    if (direction.length() > 0) {
        const angle = Math.atan2(direction.x, direction.z);
        character.rotation.y = THREE.MathUtils.lerp(character.rotation.y, angle, 8 * delta);
    }
    
    // Aplicar velocidad al personaje
    character.position.x += velocity.x * delta;
    character.position.z += velocity.z * delta;
    character.position.y += velocity.y * delta;
    
    // Colisión con el suelo
    if (character.position.y <= 0) {
        velocity.y = 0;
        character.position.y = 0;
        canJump = true;
        
        // Volver a estado idle si no se está moviendo
        if (!(moveForward || moveBackward || moveLeft || moveRight)) {
            updatePlayerState('🧍 Idle');
        }
    }
    
    // Actualizar cámara y UI
    updateCamera(delta);
    updateUI();
}

function updateCamera(delta) {
    if (!character) return;
    
    // Posición ideal de la cámara (detrás y arriba del personaje)
    const idealOffset = new THREE.Vector3(0, 6, 14);
    const idealPosition = character.position.clone().add(idealOffset);
    
    // Suavizar movimiento de cámara
    camera.position.lerp(idealPosition, 2 * delta);
    
    // Mirar al personaje
    const lookTarget = character.position.clone();
    lookTarget.y += 2;
    camera.lookAt(lookTarget);
}

function animateFloatingObjects() {
    const time = clock.getElapsedTime();
    
    scene.traverse(function(object) {
        if (object.userData && object.userData.originalY !== undefined) {
            // Movimiento de flotación
            const bobOffset = Math.sin(time * object.userData.bobSpeed) * 0.5;
            object.position.y = object.userData.originalY + bobOffset;
            
            // Rotación
            object.rotation.y += object.userData.rotationSpeed;
            object.rotation.x += object.userData.rotationSpeed * 0.5;
        }
    });
}

// ===== LOOP PRINCIPAL =====

function animate() {
    requestAnimationFrame(animate);
    
    const delta = clock.getDelta();
    
    // Actualizar animaciones del mixer
    if (mixer) {
        mixer.update(delta);
    }
    
    // Actualizar movimiento del personaje
    updateMovement(delta);
    
    // Animar objetos decorativos
    animateFloatingObjects();
    
    // Renderizar escena
    renderer.render(scene, camera);
}

// ===== FUNCIONES DE INTERFAZ =====

function updateLoadingBar(percent) {
    document.getElementById('loading-bar').style.width = percent + '%';
}

function updateLoadingText(text) {
    document.getElementById('loading-text').textContent = text;
}

function updateFileStatus(fileId, status) {
    const element = document.getElementById(fileId);
    if (element) {
        element.className = `file-${status}`;
        
        if (status === 'success') {
            element.innerHTML = element.innerHTML.replace('📁', '✅').replace('🦘', '✅');
        } else if (status === 'error') {
            element.innerHTML = element.innerHTML.replace('📁', '❌').replace('🦘', '❌');
        } else if (status === 'loading') {
            element.innerHTML = element.innerHTML.replace('📁', '⏳').replace('🦘', '⏳');
        }
    }
}

function updateCurrentAnimation(animName) {
    document.getElementById('current-anim').textContent = animName;
}

function updatePlayerState(state) {
    document.getElementById('player-state').textContent = state;
}

function updateUI() {
    if (!character) return;
    
    // Actualizar posición
    const pos = character.position;
    document.getElementById('position').textContent = 
        `${pos.x.toFixed(1)}, ${pos.y.toFixed(1)}, ${pos.z.toFixed(1)}`;
    
    // Actualizar velocidad
    const speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
    document.getElementById('speed').textContent = speed.toFixed(1);
}

// ===== EVENT LISTENERS =====

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

// ===== FUNCIONES DE EFECTOS =====

function createParticleEffect(position, color = 0xffffff) {
    const particleCount = 8;
    
    for (let i = 0; i < particleCount; i++) {
        const particleGeometry = new THREE.SphereGeometry(0.1);
        const particleMaterial = new THREE.MeshBasicMaterial({ 
            color: color,
            transparent: true,
            opacity: 0.8
        });
        const particle = new THREE.Mesh(particleGeometry, particleMaterial);
        
        particle.position.copy(position);
        particle.position.add(new THREE.Vector3(
            (Math.random() - 0.5) * 2,
            Math.random() * 2,
            (Math.random() - 0.5) * 2
        ));
        
        scene.add(particle);
        
        // Animar partícula
        const startTime = clock.getElapsedTime();
        const animateParticle = function() {
            const elapsed = clock.getElapsedTime() - startTime;
            if (elapsed > 1.5) {
                scene.remove(particle);
                return;
            }
            
            particle.position.y += 0.05;
            particle.material.opacity = Math.max(0, 0.8 - elapsed * 0.5);
            particle.scale.setScalar(Math.max(0.1, 1 - elapsed * 0.6));
            
            requestAnimationFrame(animateParticle);
        };
        animateParticle();
    }
}

// Efecto especial en salto
const originalPerformJump = performJump;
performJump = function() {
    originalPerformJump();
    if (character) {
        createParticleEffect(character.position, 0x00d4ff);
    }
};

// ===== INFORMACIÓN DE DEBUG =====

console.log("🎭 BIG VEGAS - SISTEMA COMPLETO INICIADO");
console.log("📁 Archivos configurados:");
console.log("   ✅ Big Vegas.fbx -> Modelo principal");
console.log("   ✅ Jumping Down.fbx -> Animación de salto");
console.log("");
console.log("🎮 Controles disponibles:");
console.log("   🚶 WASD -> Mover personaje");
console.log("   🦘 Espacio -> Saltar (con animación)");
console.log("   🏃 Shift -> Correr más rápido");
console.log("   🔄 R -> Reiniciar posición");
console.log("   🎬 1 -> Pose normal");
console.log("   🎬 2 -> Activar Jumping Down");
console.log("");
console.log("✨ Efectos especiales incluidos");
console.log("🎯 ¡Listo para jugar!");